#!/bin/bash

rm attach dettach
