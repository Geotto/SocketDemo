#!/bin/bash

java -classpath dumpto-1.0-SNAPSHOT.jar com.dipper.dumpto.Main attach src dst
