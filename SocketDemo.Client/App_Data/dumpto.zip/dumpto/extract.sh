#!/bin/bash

./dumpto extract attach
mv extract dettach
