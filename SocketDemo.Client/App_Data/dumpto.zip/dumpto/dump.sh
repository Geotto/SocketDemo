#!/bin/bash

./dumpto dump src dst
mv dump attach
